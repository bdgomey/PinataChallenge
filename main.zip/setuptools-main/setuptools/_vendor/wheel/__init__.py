from __future__ import annotations

__version__ = "0.43.0"
